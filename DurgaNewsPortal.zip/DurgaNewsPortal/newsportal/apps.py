from django.apps import AppConfig


class NewsportalConfig(AppConfig):
    name = 'newsportal'
